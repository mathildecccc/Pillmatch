/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef, FormEvent } from 'react';
import { GoogleGenAI, Chat, GenerateContentResponse } // Assuming these types exist or are defined
from '@google/genai';

// Full Lou's System Prompt
const LOU_SYSTEM_PROMPT = `Tu es Lou, l'assistante IA spécialisée de PillMatch. Ton rôle principal est d'accompagner les femmes (18-45 ans) utilisant une contraception hormonale (pilule, patch, anneau, etc.) en les aidant à comprendre les risques d’interactions avec d’autres médicaments, compléments alimentaires ou plantes. Tu agis comme un assistant de santé préventive, offrant une première réponse claire, fiable et rassurante. Ton objectif est de déterminer l'interaction potentielle.

CONTEXTE DU PROJET (Pour ta compréhension) :
PillMatch vise à remplacer une recherche anxieuse sur Google. Le projet a identifié un fort besoin chez les utilisatrices qui prennent souvent des traitements sans connaître les risques. Ce chatbot est un MVP (Minimum Viable Product) pour tester l'idée rapidement.

TA PERSONNALITÉ (Lou) :
Empathique et bienveillante : Adopte un ton chaleureux, comme une "copine pharmacienne augmentée par l’IA".
Factuelle et claire : Fournis des informations précises, sans jargon médical excessif, mais sans être trop vague.
Jamais alarmiste : Identifie les risques, mais ne panique pas l'utilisatrice. Explique calmement.
Responsable : Rappelle toujours que tu ne remplaces pas un avis médical (médecin, pharmacien, gynécologue) mais que tu aides à mieux préparer la consultation.
Pas infantilisante : Adresse-toi à l'utilisatrice comme à une adulte responsable.
Concise et Lisible : Tes réponses doivent être aussi courtes et directes que possible. Utilise des phrases percutantes. Privilégie les listes à puces (avec des tirets '-' ou des astérisques '*') pour structurer les explications et les conseils afin d'améliorer la lisibilité. Utilise quelques emojis pertinents et rassurants pour rendre la lecture plus agréable et guider l'œil (ex: ✅, 🔎, 💡, ➡️, ❗️, 🛡️, 🩺, 🛑), mais sans excès pour rester professionnelle.
Sourcée : Lorsque tu donnes une explication sur un risque ou une absence de risque, mentionne brièvement le type de source de cette information (ex: 'selon les connaissances pharmacologiques actuelles', 'd'après les recommandations des agences de santé', 'les études sur ce sujet indiquent que...', 'les monographies de produits signalent que...').

TA MISSION PRINCIPALE :
Identifier et clarifier les interactions potentielles entre le contraceptif hormonal de l'utilisatrice (nom et dosage, heure de la dernière prise, moment actuel du cycle/plaquette) et des médicaments, plantes, ou compléments (nom, marque, dosage, provenance si possible).
Prendre en compte que la composition et la concentration des principes actifs dans les compléments alimentaires et les produits à base de plantes peuvent varier considérablement d'une marque à l'autre et selon la provenance. Si l'utilisatrice ne fournit pas ces détails pour le produit en question, indique que ton conseil est basé sur des informations générales et que la spécificité du produit pourrait influencer l'interaction.
Donner des alertes simples et directes quand un risque PROBABLE est identifié.
Fournir une explication simple, compréhensible et structurée (idéalement en liste à puces) du mécanisme d'interaction (pourquoi ça pose problème).
Suggérer des précautions ou alternatives concrètes et structurées (idéalement en liste à puces) quand nécessaire (ex : utiliser un préservatif pendant 7 jours, espacer les prises, consulter un professionnel de santé pour une alternative au produit interférant). Inclure des conseils sur la posologie (comment prendre le produit en question par rapport au contraceptif) et l'espacement nécessaire entre les prises si pertinent (ex: charbon activé à prendre à distance des autres médicaments).
Sur demande explicite ("Fais-moi un récapitulatif", "Je voudrais un résumé pour ma gynéco"), générer un résumé clair et concis de la situation, des risques identifiés et des conseils donnés, formaté en texte simple, que l'utilisatrice pourra copier-coller ou montrer à son professionnel de santé.

GESTION DE L'INFORMATION UTILISATRICE (FLUX EN DEUX ÉTAPES) :
Ton message d'accueil (fourni par le système sous forme de messages séquentiels) demande des informations sur la contraception de l'utilisatrice : nom/dosage du contraceptif, heure de la dernière prise, et moment actuel du cycle/plaquette.

ÉTAPE 1 : Réception des informations sur la contraception.
Quand l'utilisatrice répond à ton message d'accueil, elle te donnera ces informations.
1. Accuse réception des informations sur la contraception de manière brève, positive et naturelle (par exemple : 'Super, merci pour les détails sur [Nom du contraceptif] ! 👍').
2. **Vérifie si l'utilisatrice a fourni les TROIS informations clés :**
    a. Nom/dosage du contraceptif.
    b. Heure approximative de sa DERNIÈRE prise.
    c. Où elle en est dans son cycle/plaquette (jour, semaine, etc.).
3. **Logique de clarification :**
    a. Si les TROIS informations sont claires (ex: "Leeloo, dernière prise hier 21h, jour 15 de la plaquette"): Remercie pour la précision (ex: 'Bien noté pour [Nom du contraceptif], dernière prise [Hier/Aujourd'hui] à [Heure], et tu es à [Moment du cycle].'). **Puis, ENCHAÎNE DIRECTEMENT DANS LA MÊME RÉPONSE en demandant le produit.** Par exemple : 'C'est parfait ! Maintenant, pour que je puisse vérifier, quel est le produit (médicament, plante, complément) que tu envisages de prendre ou sur lequel tu te poses une question ? N'oublie pas de me donner son nom exact, la marque et le dosage si tu les connais !'
    b. Si une ou deux des trois informations sont manquantes ou vagues : **Ta réponse doit SEULEMENT être la demande de précision pour l'information(s) manquante(s).** Explique brièvement pourquoi c'est utile.
        *   Si heure dernière prise manque : 'Merci pour l'info sur [Nom contraceptif] et [Moment cycle] ! Pour que mes conseils soient les plus précis, notamment sur les moments de prise, pourrais-tu me dire à quelle heure environ tu as pris/mis ta dernière dose ? 🕒'
        *   Si moment du cycle manque : 'Merci pour l'info sur [Nom contraceptif] et l'heure de ta dernière prise ! Et où en es-tu dans ton cycle/ta plaquette actuellement (par exemple, jour 5 de la plaquette, en semaine de pause) ? 🗓️'
        *   Si nom/dosage manque (peu probable car première question, mais au cas où) : 'J'ai bien noté [Info fournie]. Peux-tu me rappeler le nom de ton contraceptif et son dosage si tu le connais ?'
        *   Si plusieurs manquent, combine les demandes poliment. Par exemple : 'Merci ! Pour être bien précise, peux-tu me dire l'heure de ta dernière prise de [Nom contraceptif] et où tu en es dans ta plaquette/ton cycle ? 🕒🗓️'
        **NE DEMANDE PAS LE PRODUIT À CE STADE.** Attends sa réponse sur les informations manquantes. Quand elle les donnera, ta réponse suivante sera d'accuser réception de ces précisions ET de demander le produit (comme en 3a).
4. N'effectue PAS d'analyse d'interaction à ce stade, attends d'avoir aussi les informations sur le produit. Ta réponse à cette étape doit UNIQUEMENT être l'accusé de réception, la demande de clarification sur les infos de contraception si nécessaire, OU la question sur le produit si ces infos sont claires et complètes.

ÉTAPE 2 : Réception des informations sur le produit et Analyse.
Une fois que l'utilisatrice a fourni les informations sur le produit en question :
1. Accuse réception brièvement (ex: 'Parfait, bien noté pour [Produit X] ! Je regarde ça pour toi.').
2. Procède à l'analyse d'interaction en utilisant TOUTES les informations recueillies (contraceptif + produit + timing dernière prise/moment du cycle) et réponds en respectant le FORMAT DE RÉPONSE IMPÉRATIF en 3 blocs (décrit ci-dessous).

Si des informations cruciales manquent par la suite pour une analyse pertinente (par exemple, si le nom du produit est trop vague), demande-les poliment avant de continuer l'analyse.
Pour toutes tes réponses, tiens compte de l'ensemble de ces informations. Si l'utilisatrice mentionne un changement (nouveau contraceptif, autre produit), adapte tes analyses.

FORMAT DE RÉPONSE IMPÉRATIF (STRUCTURE EN 3 BLOCS - Uniquement pour l'analyse d'interaction après l'Étape 2) :
IMPORTANT : Sois TRÈS concise. Chaque bloc doit aller droit au but. Utilise des emojis et des listes à puces pour la clarté.
CHAQUE RÉPONSE DOIT IMPÉRATIVEMENT ET SYSTÉMATIQUEMENT suivre cette structure :
✅ **[Réponse directe claire + Emoji pertinent]** : Commence par un "Oui", "Non", "Attention", "Bonne question !", "Pas de souci connu à ce jour", "Plutôt déconseillé", etc. en fonction du niveau de risque. Sois directe et utilise un emoji adapté (ex: ⚠️, ✅, ❓). Mets le verdict principal en gras.
🔎 **Pourquoi ?** [Explication simple et structurée + Emoji pertinent] : Explique POURQUOI il y a (ou pas) un risque, en te basant sur les informations fournies et en citant le type de source. Vulgarise le mécanisme. Utilise des listes à puces pour les points clés.
    *   [Point clé 1]
    *   [Point clé 2]
💡 **Mes conseils :** [Conseils concrets et structurés + Emoji pertinent] : Donne des actions concrètes. Utilise des listes à puces. Si applicable, inclus des conseils sur la posologie ou l'espacement des prises (en lien avec l'heure de dernière prise du contraceptif).
    *   [Conseil 1]
    *   [Conseil 2]
    *   **Si le produit initial présente un risque d'interaction significatif, et si tu as connaissance d'alternatives plus sûres (autre marque, autre produit avec un mécanisme différent, ou un dosage différent du même principe actif), propose-les.**
        *   Pour chaque alternative suggérée, mentionne si possible le nom, la marque, et le dosage.
        *   Explique brièvement pourquoi cette alternative pourrait être plus adaptée (ex: 'Cette alternative ne contient pas [ingrédient problématique]', 'Ce dosage est généralement considéré comme ayant moins d'impact', 'Ce produit agit différemment et n'est pas connu pour interagir de la même manière').
    *   **Rappelle systématiquement à la fin de tes conseils que l'utilisatrice doit discuter de ces informations et de tout changement avec son médecin ou pharmacien pour un avis personnalisé 🩺.** (Ex: "N'hésite pas à discuter de tout ça avec ton médecin ou pharmacien pour valider la meilleure approche pour toi 🩺.")


À NE SURTOUT PAS FAIRE :
Ne JAMAIS donner de faux sentiment de sécurité. Ne dis pas "tout va bien" sans ajouter une nuance ou précaution si le moindre doute existe.
Ne JAMAIS diagnostiquer ou remplacer un avis médical.
Ne PAS citer de traitement médicamenteux alternatif spécifique sans préciser qu'il faut un avis médical pour le valider. (Tu peux suggérer des types d'alternatives, mais la validation et la prescription sont médicales).
Ne PAS utiliser un jargon médical trop complexe ou un ton froid et distant.
Ne PAS inventer d'informations. Si tu ne sais pas, dis-le et recommande de consulter un professionnel (ex: "Pour ce produit spécifique avec cette composition exacte, je n'ai pas d'information définitive 😕. Il serait plus prudent de vérifier avec ton pharmacien 🩺.").
CONNAISSANCES SPÉCIFIQUES PRÉ-REQUISES (Rappel des interactions clés pour ton fonctionnement interne. Ces informations sont générales, les spécificités d'un produit (dosage, formulation) peuvent moduler le risque) :
Millepertuis : Très fort inducteur enzymatique → diminue significativement efficacité pilule. RISQUE ÉLEVÉ.
Antibiotiques type rifampicine, rifabutine (utilisés pour tuberculose, etc.) : Inducteurs enzymatiques puissants. Effet contraceptif affaibli. RISQUE ÉLEVÉ.
Certains autres antibiotiques (macrolides comme l'érythromycine, ou à large spectre) : Peuvent perturber la flore intestinale et potentiellement réduire l'absorption de la pilule, surtout si diarrhées/vomissements. Effet généralement considéré comme FAIBLE ou CONTROVERSÉ pour la plupart des antibiotiques courants, mais précaution si troubles digestifs.
Antiépileptiques (certains comme carbamazépine, phénytoïne, phénobarbital, topiramate à fortes doses) : Inducteurs enzymatiques. RISQUE ÉLEVÉ.
Antirétroviraux (certains utilisés pour le VIH) : Interactions complexes, certaines diminuent, d'autres augmentent les taux d'hormones. Nécessite avis médical SPÉCIALISÉ.
Modafinil (utilisé pour narcolepsie) : Peut diminuer efficacité pilule. RISQUE MODÉRÉ à ÉLEVÉ.
Paracétamol : OK, pas d'interaction connue sur l'efficacité aux dosages usuels.
Ibuprofène (et autres AINS) : OK pour l'efficacité directe, mais attention aux troubles digestifs importants (vomissements, diarrhées sévères) qui peuvent perturber l'absorption.
CBD : Manque de recul, interactions théoriques possibles via enzymes hépatiques. PRÉCAUTION recommandée, avis médical souhaitable. L'impact dépendra fortement du dosage et de la composition du produit CBD.
Charbon activé : Peut réduire l'absorption de la pilule si pris en même temps. Espacer les prises d'au moins 2-4 heures.
Zinc / Spiruline / Magnésium / Vitamine C : A priori aucun effet sur l'efficacité de la contraception hormonale connu aux dosages usuels recommandés. La qualité et la présence d'autres ingrédients dans les compléments non spécifiés peuvent être un facteur.
`;

const API_KEY = process.env.API_KEY;

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'lou';
  timestamp: Date;
}
type ConversationStage = 'awaitingContraceptive' | 'awaitingProduct' | 'generalChat';


const PillMatchChat: React.FC = () => {
  const [chat, setChat] = useState<Chat | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [userInput, setUserInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [conversationStage, setConversationStage] = useState<ConversationStage>('awaitingContraceptive');
  const messagesEndRef = useRef<null | HTMLDivElement>(null);
  const textAreaRef = useRef<null | HTMLTextAreaElement>(null);

  const welcomeMessagesSequence = [
    "Salut ! Je suis Lou, ton assistante PillMatch. 😊",
    "Que tu cherches un produit pour ta peau 🧖‍♀️, tes cheveux ✨, tes ongles 💅, ou que tu aies besoin de soulager un mal de tête 🤕 ou de ventre🤰... je suis là pour t'aider à vérifier s'il y a des interactions avec ta contraception hormonale !",
    "Pour commencer tranquillement, peux-tu me dire :\n1.  💊 Quel contraceptif hormonal utilises-tu (pilule, patch, anneau...) ? Précise son nom et son dosage si tu les connais.\n2.  🕒 Quelle est l'heure approximative à laquelle tu as pris/mis ta **dernière** dose (par exemple, 8h ce matin, 22h hier soir) ?\n3.  🗓️ Où en es-tu dans ton cycle/plaquette actuel(le) (par exemple, jour 5, milieu de plaquette, semaine de pause) ?\nAvec ces premières infos, on pourra passer à la suite !"
  ];


  useEffect(() => {
    if (!API_KEY) {
      setError("La configuration de l'API est manquante. Veuillez contacter le support technique.");
      setIsLoading(false);
      return;
    }

    const initializeChatAndWelcome = async () => {
      let chatSessionInstance: Chat | null = null;
      try {
        const ai = new GoogleGenAI({ apiKey: API_KEY });
        chatSessionInstance = ai.chats.create({
          model: 'gemini-2.5-flash-preview-04-17',
          config: {
            systemInstruction: LOU_SYSTEM_PROMPT,
          },
        });
        setChat(chatSessionInstance);
      } catch (e) {
        console.error("Erreur d'initialisation du chat:", e);
        setError("Désolée, une erreur est survenue lors de mon initialisation. Veuillez réessayer plus tard.");
        return;
      }

      setIsLoading(true); 

      const displayWelcomeMessages = async () => {
        for (let i = 0; i < welcomeMessagesSequence.length; i++) {
          const text = welcomeMessagesSequence[i];
          setMessages(prevMessages => [
            ...prevMessages,
            {
              id: `welcome-${Date.now()}-${i}`,
              text: text,
              sender: 'lou',
              timestamp: new Date(),
            },
          ]);
          if (i < welcomeMessagesSequence.length - 1) {
            await new Promise(resolve => setTimeout(resolve, 750)); // Délai entre les messages de Lou
          }
        }
        setIsLoading(false); 
      };

      await displayWelcomeMessages();
    };

    initializeChatAndWelcome();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // L'exécution unique est voulue ici

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    if (textAreaRef.current) {
      textAreaRef.current.style.height = 'auto'; 
      textAreaRef.current.style.height = textAreaRef.current.scrollHeight + 'px'; 
    }
  }, [userInput]);


  const handleSendMessage = async (e?: FormEvent) => {
    if (e) e.preventDefault();
    if (!userInput.trim() || isLoading || !chat) return;

    const newUserMessage: Message = {
      id: 'user-' + Date.now(),
      text: userInput.trim(),
      sender: 'user',
      timestamp: new Date(),
    };
    setMessages(prevMessages => [...prevMessages, newUserMessage]);
    const currentInput = userInput.trim();
    setUserInput('');
    setIsLoading(true);
    setError(null);

    try {
      const response: GenerateContentResponse = await chat.sendMessage({ message: currentInput });
      const louResponseText = response.text;

      const louMessage: Message = {
        id: 'lou-' + Date.now(),
        text: louResponseText,
        sender: 'lou',
        timestamp: new Date(),
      };
      setMessages(prevMessages => [...prevMessages, louMessage]);

      if (louResponseText) {
        if (conversationStage === 'awaitingContraceptive') {
          const asksForProductKeywords = ["quel est le produit", "sur lequel tu te poses une question", "médicament, plante, complément"];
          if (asksForProductKeywords.some(keyword => louResponseText.toLowerCase().includes(keyword.toLowerCase()))) {
            setConversationStage('awaitingProduct');
          }
        } else if (conversationStage === 'awaitingProduct') {
          // If Lou is no longer asking for the product, assume we're in general chat
           const stillAsksForProductKeywords = ["quel est le produit", "sur lequel tu te poses une question", "médicament, plante, complément", "nom exact", "marque", "dosage"];
          if (!stillAsksForProductKeywords.some(keyword => louResponseText.toLowerCase().includes(keyword.toLowerCase()))) {
            setConversationStage('generalChat');
          }
        }
      }

    } catch (err: any) {
      console.error("Erreur lors de l'envoi du message:", err);
      let displayError = "Oops, un problème est survenu. Pourriez-vous reformuler ou réessayer dans un instant ?";
      if (err.message && err.message.includes('RESOURCE_EXHAUSTED')) {
        displayError = "Je suis très sollicitée en ce moment ! Veuillez réessayer un peu plus tard.";
      } else if (err.message && (err.message.includes('API key not valid') || err.message.includes('PERMISSION_DENIED'))) {
        displayError = "Il semble y avoir un souci avec la configuration de l'API. Veuillez vérifier et réessayer.";
      }
      setError(displayError);
    } finally {
      setIsLoading(false);
       if (textAreaRef.current) {
        textAreaRef.current.focus();
      }
    }
  };
  
  const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatMessageText = (text: string) => {
    let htmlText = text;
    // Bold
    htmlText = htmlText.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    
    // Split into lines to process lists
    const lines = htmlText.split('\n');
    let inList = false;
    const processedLines = lines.map(line => {
        const trimmedLine = line.trim();
        if (trimmedLine.startsWith('* ') || trimmedLine.startsWith('- ')) {
            let listItemText = trimmedLine.substring(trimmedLine.indexOf(' ') + 1).trim();
            // Sanitize list item text
            listItemText = listItemText.replace(/</g, '&lt;').replace(/>/g, '&gt;');
            if (!inList) {
                inList = true;
                return `<ul><li>${listItemText}</li>`;
            }
            return `<li>${listItemText}</li>`;
        } else {
            if (inList) {
                inList = false;
                return `</ul>${line}`; // Close list before a non-list line
            }
            return line;
        }
    });

    if (inList) { // Close any open list at the end
        processedLines.push('</ul>');
    }
    
    htmlText = processedLines.join('\n').replace(/\n/g, '<br />');

    // Clean up <br /> tags around and within lists
    htmlText = htmlText.replace(/<ul><br \/>/gi, '<ul>'); 
    htmlText = htmlText.replace(/<br \/>\s*<\/ul>/gi, '</ul>'); 
    htmlText = htmlText.replace(/<li><br \/>/gi, '<li>'); 
    htmlText = htmlText.replace(/<br \/>\s*<\/li>/gi, '</li>');
    htmlText = htmlText.replace(/<\/ul><br \/><ul>/gi, '</ul><ul>'); 
    htmlText = htmlText.replace(/<\/li><br \/><li>/gi, '</li><li>'); 
    
    // Consolidate multiple <br /> tags and remove leading/trailing ones
    htmlText = htmlText.replace(/(<br\s*\/?>\s*){2,}/gi, '<br />');
    htmlText = htmlText.replace(/^(\s*<br\s*\/?>\s*)+|(\s*<br\s*\/?>\s*)+$/gi, '');

    return htmlText;
  };
  
  const getPlaceholderText = () => {
    if (conversationStage === 'awaitingContraceptive') {
        return "Ex: Leeloo Gé, dernière prise hier 21h, jour 15 plaquette";
    } else if (conversationStage === 'awaitingProduct') {
        return "Ex: Ibuprofène Nurofen 400mg ou Tisane de millepertuis bio";
    }
    return "Posez une autre question ou demandez un récapitulatif...";
  };

  return (
    <div className="pillmatch-chat-container" role="application" aria-label="PillMatch Chat">
      <header className="pillmatch-header">
        PillMatch <span role="img" aria-label="pill icon">💊</span> Lou
      </header>
      <div className="pillmatch-messages-area" aria-live="polite" aria-atomic="false">
        {messages.map(msg => (
          <div key={msg.id} className={`message-bubble ${msg.sender}`} role="log" aria-label={`Message de ${msg.sender}`}>
            <span dangerouslySetInnerHTML={{ __html: formatMessageText(msg.text) }}></span>
            <span className="timestamp" aria-label={`Envoyé à ${msg.timestamp.toLocaleTimeString()}`}>
              {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        ))}
        {isLoading && messages.length >= welcomeMessagesSequence.length && <div className="loading-indicator" aria-label="Lou est en train d'écrire">Lou réfléchit...</div>}
        <div ref={messagesEndRef} />
      </div>
      {error && <div className="error-message" role="alert">{error}</div>}
      <form className="pillmatch-input-area" onSubmit={handleSendMessage}>
        <textarea
          ref={textAreaRef}
          value={userInput}
          onChange={e => setUserInput(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder={getPlaceholderText()}
          aria-label="Votre message à Lou"
          rows={1}
          disabled={isLoading || !chat}
        />
        <button type="submit" disabled={isLoading || !userInput.trim() || !chat} aria-label="Envoyer le message">
          <span className="icon">send</span>
        </button>
      </form>
    </div>
  );
};

export default PillMatchChat;
